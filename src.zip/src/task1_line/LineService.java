package task1_line;

public class LineService {
    // Задание 2.1: Сдвиг точки начала линии на 10 единиц по оси X
    public static void shiftLineStart(Line<?> line) {
        Point2D start = line.getStart();
        double currentX = start.getX();
        if (currentX >= 0) {
            start.setX(currentX + 10);
        } else {
            start.setX(currentX - 10);
        }
    }
}