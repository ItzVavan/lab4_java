package task3_generics;
import java.util.ArrayList;
import java.util.List;

import task3_generics.collect.ResultFactory;
import task3_generics.collect.ResultWriter;
import task3_generics.function.Transformer;
import task3_generics.reduce.Combiner;
import task3_generics.filter.Condition;

public class GenericUtils {

    // 3.1 Функция
    public static <T, P> List<P> transform(List<T> source, Transformer<T, P> transformer) {
        List<P> result = new ArrayList<>();
        for (T item : source) {
            result.add(transformer.apply(item));
        }
        return result;
    }

    // 3.2 Фильтр
    public static <T> List<T> filter(List<T> source, Condition<T> condition) {
        List<T> result = new ArrayList<>();
        for (T item : source) {
            if (condition.test(item)) {
                result.add(item);
            }
        }
        return result;
    }

    // 3.3 Сокращение (с защитой от null и пустых коллекций)
    public static <T> T reduce(List<T> source, Combiner<T> combiner, T identity) {
        T result = identity;
        if (source != null) {
            for (T item : source) {
                result = combiner.combine(result, item);
            }
        }
        return result;
    }

    // 3.4 Коллекционирование
    public static <T, R> R collect(List<T> source, ResultFactory<R> factory, ResultWriter<R, T> writer) {
        R result = factory.create();
        if (source != null) {
            for (T item : source) {
                writer.add(result, item);
            }
        }
        return result;
    }
}