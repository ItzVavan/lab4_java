package task3_generics.collect;
public interface ResultWriter<R, T> {
    void add(R result, T value);
}