package task3_generics.collect;
public interface ResultFactory<R> {
    R create();
}