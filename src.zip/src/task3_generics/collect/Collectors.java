package task3_generics.collect;
import java.util.*;

public class Collectors {

    // 1. Разделение на положительные и отрицательные
    public static class NumberPartitionFactory implements ResultFactory<Map<String, List<Integer>>> {
        @Override
        public Map<String, List<Integer>> create() {
            Map<String, List<Integer>> map = new LinkedHashMap<>();
            map.put("positive", new ArrayList<>());
            map.put("negative", new ArrayList<>());
            return map;
        }
    }

    public static class NumberPartitionWriter implements ResultWriter<Map<String, List<Integer>>, Integer> {
        @Override
        public void add(Map<String, List<Integer>> result, Integer value) {
            if (value >= 0) {
                result.get("positive").add(value);
            } else {
                result.get("negative").add(value);
            }
        }
    }

    // 2. Группировка строк по длине
    public static class GroupByLengthFactory implements ResultFactory<Map<Integer, List<String>>> {
        @Override
        public Map<Integer, List<String>> create() {
            return new LinkedHashMap<>();
        }
    }

    public static class GroupByLengthWriter implements ResultWriter<Map<Integer, List<String>>, String> {
        @Override
        public void add(Map<Integer, List<String>> result, String value) {
            int len = value.length();
            if (!result.containsKey(len)) {
                result.put(len, new ArrayList<>());
            }
            result.get(len).add(value);
        }
    }

    // 3. Уникальный набор
    public static class UniqueSetFactory<T> implements ResultFactory<Set<T>> {
        @Override
        public Set<T> create() {
            return new LinkedHashSet<>();
        }
    }

    public static class UniqueSetWriter<T> implements ResultWriter<Set<T>, T> {
        @Override
        public void add(Set<T> result, T value) {
            result.add(value);
        }
    }
}