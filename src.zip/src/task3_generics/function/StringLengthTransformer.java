package task3_generics.function;

public class StringLengthTransformer implements Transformer<String, Integer> {
    @Override
    public Integer apply(String value) {
        return value.length();
    }
}