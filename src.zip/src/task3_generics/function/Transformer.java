package task3_generics.function;
public interface Transformer<T, P> {
    P apply(T value);
}