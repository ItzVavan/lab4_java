package task3_generics.function;

public class MaxArrayTransformer implements Transformer<int[], Integer> {
    @Override
    public Integer apply(int[] array) {
        if (array == null || array.length == 0) {
            return 0;
        }
        int max = array[0];
        for (int v : array) {
            if (v > max) max = v;
        }
        return max;
    }
}