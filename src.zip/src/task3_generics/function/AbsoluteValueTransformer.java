package task3_generics.function;

public class AbsoluteValueTransformer implements Transformer<Integer, Integer> {
    @Override
    public Integer apply(Integer value) {
        return Math.abs(value);
    }
}