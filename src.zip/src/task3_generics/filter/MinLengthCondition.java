package task3_generics.filter;
public class MinLengthCondition implements Condition<String> {
    private final int minLength;
    public MinLengthCondition(int minLength) { this.minLength = minLength; }

    @Override
    public boolean test(String value) {
        return value != null && value.length() >= minLength;
    }
}