package task3_generics.filter;
public interface Condition<T> {
    boolean test(T value);
}