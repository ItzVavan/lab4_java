package task3_generics.filter;

public class NegativeOrZeroCondition implements Condition<Integer> {
    @Override
    public boolean test(Integer value) {
        return value <= 0;
    }
}
