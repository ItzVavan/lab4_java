package task3_generics.filter;

public class NoPositiveElementsCondition implements Condition<int[]> {
    @Override
    public boolean test(int[] array) {
        if (array == null) return true;
        for (int val : array) {
            if (val > 0) return false;
        }
        return true;
    }
}