package task3_generics.reduce;
public interface Combiner<T> {
    T combine(T left, T right);
}