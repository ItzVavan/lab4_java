package task3_generics.reduce;

public class StringConcatCombiner implements Combiner<String> {
    @Override
    public String combine(String left, String right) {
        return left + right;
    }
}