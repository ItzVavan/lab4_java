package task3_generics.reduce;

public class IntegerSumCombiner implements Combiner<Integer> {
    @Override
    public Integer combine(Integer left, Integer right) {
        return left + right;
    }
}