package task1_storage;
public final class Storage<T> {
    private final T item;

    public Storage(T item) {
        this.item = item;
    }

    public T getOrDefault(T alternative) {
        return (this.item != null) ? this.item : alternative;
    }

    public T getItem() {
        return this.item;
    }

    @Override
    public String toString() {
        return "Storage{" + "item=" + item + '}';
    }
}