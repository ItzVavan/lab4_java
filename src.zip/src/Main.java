import java.util.*;

import task1_line.Line;
import task1_line.LineService;
import task1_line.Point3D;
import task1_storage.Storage;
import task3_generics.GenericUtils;
import task3_generics.collect.Collectors;
import task3_generics.filter.MinLengthCondition;
import task3_generics.filter.NegativeOrZeroCondition;
import task3_generics.filter.NoPositiveElementsCondition;
import task3_generics.function.AbsoluteValueTransformer;
import task3_generics.function.MaxArrayTransformer;
import task3_generics.function.StringLengthTransformer;
import task3_generics.function.Transformer;
import task3_generics.reduce.IntegerSumCombiner;
import task3_generics.reduce.StringConcatCombiner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n========== ЛАБОРАТОРНАЯ РАБОТА №4 (ВАРИАНТ 1) ==========");
            System.out.println("1. Задание 1.2: Демонстрация класса 'Хранилище' (Без null)");
            System.out.println("2. Задание 1.5 и 2.1: 'Линия в 3D' и 'Сдвиг точки начала'");
            System.out.println("3. Задание 3.1: Универсальный метод 'Функция'");
            System.out.println("4. Задание 3.2: Универсальный метод 'Фильтр'");
            System.out.println("5. Задание 3.3: Универсальный метод 'Сокращение'");
            System.out.println("6. Задание 3.4: Универсальный метод 'Коллекционирование'");
            System.out.println("0. Выход");
            System.out.print("Выберите пункт меню: ");

            int choice = readInt();
            switch (choice) {
                case 1 -> testStorage();
                case 2 -> testLineAndShift();
                case 3 -> testTransform();
                case 4 -> testFilter();
                case 5 -> testReduce();
                case 6 -> testCollect();
                case 0 -> {
                    System.out.println("Программа завершена.");
                    return;
                }
                default -> System.out.println("Неверный пункт. Повторите ввод.");
            }
        }
    }

    // --- Обработчик 1.2 ---
    private static void testStorage() {
        System.out.println("\n--- Задание 1.2: Хранилище ---");
        // Число null -> альт 0
        Storage<Integer> s1 = new Storage<>(null);
        printStorageResult(s1, 0);

        // Ввод числа пользователем с проверкой
        System.out.print("Введите целое число для Хранилища (по умолчанию в методичке 99): ");
        int userNum = readInt();
        Storage<Integer> s2 = new Storage<>(userNum);
        printStorageResult(s2, -1);

        // Строка null -> альт "default"
        Storage<String> s3 = new Storage<>(null);
        printStorageResult(s3, "default");

        // Строка пользователя
        System.out.print("Введите строку для Хранилища (по умолчанию в методичке 'hello'): ");
        String userStr = scanner.nextLine();
        Storage<String> s4 = new Storage<>(userStr);
        printStorageResult(s4, "hello world");
    }

    private static <T> void printStorageResult(Storage<T> storage, T alternative) {
        System.out.println("Объект: " + storage);
        System.out.println("Извлечённое значение (с альтернативой " + alternative + "): " + storage.getOrDefault(alternative));
    }

    // --- Обработчик 1.5 и 2.1 ---
    private static void testLineAndShift() {
        System.out.println("\n--- Задания 1.5 и 2.1: Линия 3D и Сдвиг ---");
        System.out.println("Введите координаты начала трёхмерной линии (x1, y1, z1):");
        double x1 = readDouble("x1: ");
        double y1 = readDouble("y1: ");
        double z1 = readDouble("z1: ");

        System.out.println("Введите координаты конца трёхмерной линии (x2, y2, z2):");
        double x2 = readDouble("x2: ");
        double y2 = readDouble("y2: ");
        double z2 = readDouble("z2: ");

        Point3D p1 = new Point3D(x1, y1, z1);
        Point3D p2 = new Point3D(x2, y2, z2);
        Line<Point3D> line3D = new Line<>(p1, p2);

        System.out.println("\nСозданная линия: " + line3D);
        LineService.shiftLineStart(line3D);
        System.out.println("Линия после вызова shiftLineStart (сдвиг X на 10): " + line3D);
    }

    // --- Обработчик 3.1 ---
    private static void testTransform() {
        System.out.println("\n--- Задание 3.1: Функция (apply) ---");

        // Пример 1: Строки в их длины
        List<String> strList = List.of("qwerty", "asdfg", "zx");
        List<Integer> lengths = GenericUtils.transform(strList, new StringLengthTransformer());
        System.out.println("1) Исходные строки: " + strList);
        System.out.println("   Длины строк: " + lengths);

        // Пример 2: Отрицательные в положительные
        List<Integer> intList = List.of(1, -3, 7);
        List<Integer> absList = GenericUtils.transform(intList, new AbsoluteValueTransformer());
        System.out.println("2) Исходные числа: " + intList);
        System.out.println("   Модули чисел: " + absList);

        // Пример 3: Максимумы из массивов
        List<int[]> arraysList = new ArrayList<>();
        arraysList.add(new int[]{1, 5, 3});
        arraysList.add(new int[]{-10, -2, -8});
        arraysList.add(new int[]{42, 0});
        List<Integer> maxValues = GenericUtils.transform(arraysList, new MaxArrayTransformer());
        System.out.println("3) Массивы: [1, 5, 3], [-10, -2, -8], [42, 0]");
        System.out.println("   Максимумы: " + maxValues);
    }

    // --- Обработчик 3.2 ---
    private static void testFilter() {
        System.out.println("\n--- Задание 3.2: Фильтр (test) ---");

        // Пример 1: Строки длиной не менее 3
        List<String> strList = List.of("qwerty", "asdfg", "zx");
        List<String> filteredStr = GenericUtils.filter(strList, new MinLengthCondition(3));
        System.out.println("1) Исходные строки: " + strList);
        System.out.println("   Отфильтровано (длина >= 3): " + filteredStr);

        // Пример 2: Исключить положительные (оставить <= 0)
        List<Integer> intList = List.of(1, -3, 7);
        List<Integer> filteredInt = GenericUtils.filter(intList, new NegativeOrZeroCondition());
        System.out.println("2) Исходные числа: " + intList);
        System.out.println("   Отфильтровано (удалены положительные): " + filteredInt);

        // Пример 3: Массивы без положительных чисел
        List<int[]> arraysList = new ArrayList<>();
        arraysList.add(new int[]{-1, -5, -3});
        arraysList.add(new int[]{0, -2, 4});
        arraysList.add(new int[]{-8, 0, -12});
        List<int[]> filteredArrays = GenericUtils.filter(arraysList, new NoPositiveElementsCondition());
        System.out.println("3) Исходные массивы: [-1, -5, -3], [0, -2, 4], [-8, 0, -12]");
        System.out.print("   Остались массивы без положительных: ");
        for (int[] arr : filteredArrays) {
            System.out.print(Arrays.toString(arr) + " ");
        }
        System.out.println();
    }

    // --- Обработчик 3.3 ---
    private static void testReduce() {
        System.out.println("\n--- Задание 3.3: Сокращение (combine) ---");

        // Пример 1: Объединение строк
        List<String> strList = List.of("qwerty", "asdfg", "zx");
        String merged = GenericUtils.reduce(strList, new StringConcatCombiner(), "");
        System.out.println("1) Строки: " + strList + " -> Результат: \"" + merged + "\"");

        // Пример 2: Сумма чисел
        List<Integer> intList = List.of(1, -3, 7);
        int sum = GenericUtils.reduce(intList, new IntegerSumCombiner(), 0);
        System.out.println("2) Числа: " + intList + " -> Сумма: " + sum);

        // Пример 3: Общее число элементов во всех списках
        List<List<Integer>> listOfLists = List.of(
                List.of(1, 2, 3),
                List.of(4, 5),
                List.of(6, 7, 8, 9)
        );
        // Решение по подсказке из памятки: transform(3.1) -> reduce(3.3)
        List<Integer> sizes = GenericUtils.transform(listOfLists, new Transformer<List<Integer>, Integer>() {
            @Override
            public Integer apply(List<Integer> value) {
                return value.size();
            }
        });
        int totalElements = GenericUtils.reduce(sizes, new IntegerSumCombiner(), 0);
        System.out.println("3) Списки: " + listOfLists);
        System.out.println("   Общее количество элементов во всех списках: " + totalElements);

        // Проверка защиты от пустых списков
        List<Integer> emptyList = Collections.emptyList();
        int safeResult = GenericUtils.reduce(emptyList, new IntegerSumCombiner(), 0);
        System.out.println("   Проверка на пустом списке: " + safeResult + " (без исключений и null)");
    }

// --- Обработчик 3.4 ---
    private static void testCollect() {
        System.out.println("\n--- Задание 3.4: Коллекционирование ---");

        // Пример 1: Разделение на положительные и отрицательные
        List<Integer> intList = List.of(1, -3, 7, -2, 0);
        Map<String, List<Integer>> partitioned = GenericUtils.collect(
                intList,
                new Collectors.NumberPartitionFactory(),
                new Collectors.NumberPartitionWriter()
        );
        System.out.println("1) Исходные числа: " + intList);
        System.out.println("   Разбиение: " + partitioned);

        // Пример 2: Группировка строк одинаковой длины
        List<String> strList = List.of("qwerty", "asdfg", "zx", "qw");
        Map<Integer, List<String>> grouped = GenericUtils.collect(
                strList,
                new Collectors.GroupByLengthFactory(),
                new Collectors.GroupByLengthWriter()
        );
        System.out.println("2) Исходные строки: " + strList);
        System.out.println("   Сгруппированные по длине: " + grouped);

        // Пример 3: Набор без повторяющихся объектов
        List<String> duplicatesList = List.of("qwerty", "asdfg", "qwerty", "qw");
        Set<String> uniqueSet = GenericUtils.collect(
                duplicatesList,
                new Collectors.UniqueSetFactory<>(),
                new Collectors.UniqueSetWriter<>()
        );
        System.out.println("3) Список с дубликатами: " + duplicatesList);
        System.out.println("   Набор без повторений (Set): " + uniqueSet);
    }

    // --- Вспомогательные методы проверки ввода ---
    private static int readInt() {
        while (true) {
            try {
                String line = scanner.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.print("Ошибка! Введите целое число: ");
            }
        }
    }

    private static double readDouble(String prompt) {
        System.out.print(prompt);
        while (true) {
            try {
                String line = scanner.nextLine().trim().replace(',', '.');
                return Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.print("Ошибка! Введите вещественное число: ");
            }
        }
    }
}